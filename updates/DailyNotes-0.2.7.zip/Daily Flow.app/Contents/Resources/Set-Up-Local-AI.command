#!/bin/zsh
set -eu
print 'Daily Notes — free local AI setup'
print 'Downloads Ollama and qwen3:1.7b (about 1.4 GB for the model). No account or payment.'
if (( ${${$(sw_vers -productVersion)%%.*}:-0} < 14 )); then
 print 'This setup requires macOS 14 or later.'; read '?Press Return to close.'; exit 1
fi
setup_tmp=$(mktemp -d)
trap 'rm -rf "$setup_tmp"' EXIT
trap 'print "Setup did not finish. Re-run setup to retry."; read "?Press Return to close."' ZERR
ollama_app=''
for candidate in /Applications/Ollama.app "$HOME/Applications/Ollama.app"; do
 if [[ -x "$candidate/Contents/Resources/ollama" ]]; then ollama_app="$candidate"; break; fi
done
if [[ -z "$ollama_app" ]]; then
 print 'Downloading official Ollama app…'
 curl --fail --location --proto '=https' --proto-redir '=https' https://ollama.com/download/Ollama-darwin.zip -o "$setup_tmp/Ollama.zip"
 ditto -x -k "$setup_tmp/Ollama.zip" "$setup_tmp/unpacked"
 codesign --verify --deep --strict "$setup_tmp/unpacked/Ollama.app"
 spctl --assess --type execute "$setup_tmp/unpacked/Ollama.app"
 mkdir -p "$HOME/Applications"
 if [[ -e "$HOME/Applications/Ollama.app" ]]; then print 'An existing Ollama app needs attention. Please install Ollama from ollama.com.'; exit 1; fi
 ditto "$setup_tmp/unpacked/Ollama.app" "$HOME/Applications/Ollama.app"
 ollama_app="$HOME/Applications/Ollama.app"
fi
export OLLAMA_HOST='127.0.0.1:11434'
export OLLAMA_NO_CLOUD=1
if ! curl --fail --silent --max-time 2 http://127.0.0.1:11434/api/version >/dev/null; then
 print 'Starting local-only Ollama service…'
 mkdir -p "$HOME/Library/LaunchAgents" "$HOME/Library/Logs/DailyNotes"
 agent_path="$HOME/Library/LaunchAgents/local.mithun.dailynotes.ollama.plist"
 if [[ -e "$agent_path" ]]; then
  launchctl bootout "gui/$(id -u)" "$agent_path" 2>/dev/null || true
 fi
 plutil -create xml1 "$agent_path"
 plutil -insert Label -string local.mithun.dailynotes.ollama "$agent_path"
 plutil -insert ProgramArguments -array "$agent_path"
 plutil -insert ProgramArguments.0 -string "$ollama_app/Contents/Resources/ollama" "$agent_path"
 plutil -insert ProgramArguments.1 -string serve "$agent_path"
 plutil -insert EnvironmentVariables -dictionary "$agent_path"
 plutil -insert EnvironmentVariables.OLLAMA_HOST -string "$OLLAMA_HOST" "$agent_path"
 plutil -insert EnvironmentVariables.OLLAMA_NO_CLOUD -string 1 "$agent_path"
 plutil -insert RunAtLoad -bool YES "$agent_path"
 plutil -insert KeepAlive -bool YES "$agent_path"
 plutil -insert StandardOutPath -string "$HOME/Library/Logs/DailyNotes/ollama.log" "$agent_path"
 plutil -insert StandardErrorPath -string "$HOME/Library/Logs/DailyNotes/ollama.log" "$agent_path"
 launchctl bootstrap "gui/$(id -u)" "$agent_path"
 for attempt in {1..30}; do
  if curl --fail --silent --max-time 1 http://127.0.0.1:11434/api/version >/dev/null; then break; fi
  sleep 1
 done
fi
print 'Downloading local model. This may take several minutes…'
"$ollama_app/Contents/Resources/ollama" pull qwen3:1.7b
print 'Setup complete. Return to Daily Notes > Local AI work notes.'
print 'Check local AI, then enable automatic notes and optional active-window text.'
read '?Press Return to close.'
